//============================================================================
//  memory.h �u����������v Win32 ��
//----------------------------------------------------------------------------
//													Programmed by ����
//----------------------------------------------------------------------------
// 2004.02.23 Ver.1.00 �쐬.
//============================================================================
#ifndef DEFINE_MEMORY
#define DEFINE_MEMORY

// -------------------- �萔��`
#define MEMORY_MODE 0		// 0=�f�o�b�O�t��, 1=malloc/free
#define MEMORY_MAX 65536

// �֐���`
void InitMemory( void );
void* AllocateMemory( size_t size, const char *file, int line );
void FreeMemory( void *memory, const char *file, int line );
void DisplayMemory( const char *file, int line );

#endif
