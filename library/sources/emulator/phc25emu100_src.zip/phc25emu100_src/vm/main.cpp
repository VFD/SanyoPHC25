//============================================================================
//  main.cpp �u���C�����[�`���v
//----------------------------------------------------------------------------
//													Programmed by ���ӌ\��
//============================================================================
#include "main.h"
#include "../common/debug.h"
#include "../win32/memory.h"
#include "../win32/system.h"

void InitMain( void )
{
	InitRender();
	Clear();
}

void ReleaseMain( void )
{
	ReleaseRender();
}

// Out  : false = �p��, true = �I��
bool Main( void )
{
	Flip();
	Clear();
	RunCPU();
	return false;
}
