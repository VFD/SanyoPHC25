//============================================================================
//  system.h �u�݊����̂Ȃ��������z������v
//----------------------------------------------------------------------------
//													Programmed by ���ӌ\��
//============================================================================

// -------------------- 2 �d��`�h�~
#ifndef INCLUDE_SYSTEM
#define INCLUDE_SYSTEM

// -------------------- �w�b�_�t�@�C���o�^
#include <windows.h>
#include "memory.h"
#define PAD_LEFT     0x00000004	// ��
#define PAD_DOWN     0x00000002	// ��
#define PAD_RIGHT    0x00000008	// �E
#define PAD_UP       0x00000001	// ��
#define PAD_BUTTON1  0x00000010	// �{�^�� 1

// ������
#define SystemMalloc(x) AllocateMemory(x,__FILE__, __LINE__)
#define SystemFree(x) FreeMemory(x,__FILE__, __LINE__)
#define SystemMemoryStatus() DisplayMemory(__FILE__,__LINE__)
//#define SystemMalloc(x) malloc(x)
//#define SystemFree(x) free(x)
//#define SystemMemoryStatus() ;
// �V�X�e��
bool InitSystem( HWND window_handle );
void ReleaseSystem( void );
// ���
void Flip( void );
void Clear( void );
void InitRender( void );
void ReleaseRender( void );
void Render( bool fullscreen );
void SetTV( bool tv );
bool GetTV( void );
// CPU
void RunCPU( void );
void ExecRETI( void );
bool ExecInterrupt( void );
void Reset( void );
// I/O �|�[�g
unsigned char ReadIO_CPU( unsigned char laddr, unsigned char haddr );
void WriteIO_CPU( unsigned char laddr, unsigned char haddr, unsigned char val );
// �L�[�{�[�h
void SetKey( int code );
void ResetKey( int code );
// ���z�}�V���̃�����
void WriteMemoryByte( unsigned short addr, unsigned char val );
// �v�����^
void SetPrinter( void );
void WritePhcPrinter( int chr );
// �e�[�v
void SetReadTape( void );
void SetWriteTape( void );
void WriteTape( int data );
int ReadTape( void );
void RewReadTape( void );
// ���
void SetInformation( bool information );
bool GetInformation( void );
void SetInfomationMode( DWORD mode );
void ResetInfomationMode( DWORD mode );
void SetFps( float fps );
// PSG
void MakeSound( bool fill );
void UpdateSound( void );
void SetVolume( int volume );
int GetVolume( void );
void SetSound( int rate, int sample_count );
int GetSoundBuffer( void );
// �W���C�p�b�h
DWORD GetStick( int player );
// �ݒ�
void LoadSetting( void );
void SaveSetting( void );
void SetScreenScale( int scale );
int GetScreenScale( void );
void SetFullScreen( bool fullscreen );
bool GetFullScreen( void );
void SetFrameSkip( bool skip );
bool GetFrameSkip( void );

#endif
